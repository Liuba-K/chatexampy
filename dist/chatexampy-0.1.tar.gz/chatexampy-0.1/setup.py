from setuptools import setup

setup(name='chatexampy', #name задает полное имя пакета.
      version = "0.1",
      description = "example chat",
      author = "Liuba Kundas",
      author_email = "kundasl1@gmail.com",
      #url = "http://www.blog.pythonlibrary.org",
      packages=["src"]
      )
